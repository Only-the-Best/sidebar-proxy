const express = require('express');
const path = require('path');
var cors = require('cors');
const db = require('../database/index.js');
const Gallery = require('../database/Gallery.js');
// const mongoose = require('mongoose');
// const mongoUri = 'mongodb+srv://jacli1314:passwordeeznuts1@cluster0-wrvnw.mongodb.net/galleries?retryWrites=true';

// const mongoUri = 'mongodb+srv://admin1:admin1password@cluster0-ytvdt.mongodb.net/galleries?retryWrites=true';
// mongoose.connect(mongoUri, { useNewUrlParser: true });
// const db = mongoose.connection;

// const gallerySchema = new mongoose.Schema({
//     id: Number,
//     imageUrl: [String],
//     address: String,
//     zipcode: String,
//     city: String,
//     State: String,
// });

// const Gallery = mongoose.model('Gallery', gallerySchema);



const app = express();
const port = 8081;

app.use(cors());
app.use(express.static(__dirname + '/../dist/'));

app.get('/:id', (req, res) => {
	console.log('initializing page request...');
	res.sendFile(path.join(`${__dirname}/../dist/index.html`));
});

app.get('/homes/:id', (req, res) => {
	console.log('req.params.id is', req.params.id);
	console.log('typeof params.id is ', typeof req.params.id);
	req.params.id = Number(req.params.id);
	console.log('typeof params.id is ', typeof req.params.id);
	Gallery.find({id: req.params.id}, (err, data) => {
		console.log('data is ', data);
		if (err) {
			console.log("Error*: ", err);
		} else {
			res.status(200).send(data);
		}
	})
});

app.listen(port, () => {
	console.log(`listening on port ${port}`);
});



